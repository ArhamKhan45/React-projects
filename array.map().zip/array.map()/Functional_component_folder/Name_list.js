import React from "react";
// List rendering
function Name_list() {
  const city = ["Delhi", "Mumbai", "Kolkata", "Chennai"];
  return (
    <div>
      {city.map((name) => (
        <h1>{name}</h1>
      ))}
    </div>
  );
}

export default Name_list;
