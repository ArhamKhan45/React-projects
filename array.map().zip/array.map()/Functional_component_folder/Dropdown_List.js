import React from "react";
function Dropdown_List() {
  const city = [
    "Mumbai",
    "Delhi",
    "Uttar Pradesh",
    "Kolkata",
    "Goa",
    "Haryana",
  ];
  return (
    <div style={{ textAlign: "center" }}>
      <label>Choose the State</label>
      <input type="text" list="city" placeholder="state" className=""></input>
      <datalist id="city">
        {city.map((state) => (
          <option>{state}</option>
        ))}
      </datalist>

      <br></br>
      <br></br>
      <label>Choose the State</label>
      <select>
        {city.map((state) => (
          <option>{state}</option>
        ))}
      </select>
    </div>
  );
}
export default Dropdown_List;
