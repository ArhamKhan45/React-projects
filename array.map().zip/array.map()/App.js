import logo from "./logo.svg";
import "./App.css";
import Dropdown_List from "./Functional_component_folder/Dropdown_List";
import DropDown_Alert from "./Functional_component_folder/DropDown_Alert";
import ValueShifter from "./component_folder/ValueShifter";

function App() {
  return (
    <div>
      <Dropdown_List />
      <br></br>
      <DropDown_Alert />
      <br></br>
      <ValueShifter />
    </div>
  );
}

export default App;

// 1.show the  array values in the dropdown list
// 2. click on the dropdown value show alert message and include the dropdown value
// 3.value shifter
