import React from "react";
import { BrowserRouter, Route } from "react-router-dom";
import Header from "./Header";
import Profile from "./Profile";
import Footer from "./Footer";
import Post from "./Post";
import Home from "./Home";
function Routing() {
  return (
    <BrowserRouter>
      <Header />
      <Route exact path="/" component={Home} />
      <Route path="/Post" component={Post} />
      <Route path="/Profile" component={Profile} />
      <Footer />
    </BrowserRouter>
  );
}

export default Routing;
