import React from "react";

function Post() {
  return (
    <div>
      <h1>Post</h1>
    </div>
  );
}
export default Post;
