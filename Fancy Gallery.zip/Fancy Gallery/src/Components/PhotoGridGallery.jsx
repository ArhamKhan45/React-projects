import React from "react";
import SliderImages from "./SliderImages";
import LightGallery from "lightgallery/react";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-thumbnail.css";
import lgThumbnail from "lightgallery/plugins/thumbnail";
import lgZoom from "lightgallery/plugins/zoom";
import "../Style/PhotoGridGallery.css";
function PhotoGridGallery() {
  const onInit = () => {
    // console.log("lightGallery has been initialized");
  };

  const imagesDisplay = SliderImages.map((item, index) => {
    return (
      <a href={item.original} key={index}>
        <img
          src={item.src}
          alt={item.caption}
          width={item.width}
          height={item.height}
        />
      </a>
    );
  });

  return (
    <div className="text-center">
      <h1 className="fw-bolder my-5">FANCY GALLERY</h1>
      <div>
        <LightGallery
          onInit={onInit}
          speed={500}
          plugins={[lgThumbnail, lgZoom]}
        >
          {imagesDisplay}
        </LightGallery>
      </div>
    </div>
  );
}

export default PhotoGridGallery;
