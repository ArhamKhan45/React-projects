// import "./App.css";
// import CountryFlag from "./Components/CountryFlag.jsx";
import PhotoGridGallery from "./Components/PhotoGridGallery.jsx";

function App() {
  return (
    <div className="App">
      {/* <CountryFlag /> */}
      <PhotoGridGallery />
    </div>
  );
}

export default App;
