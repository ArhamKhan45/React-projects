// import React, { Component } from 'react'
// class textchange extends Component{
//     render(){
//         render()
//     }
// }

//  class component start
import React, { Component } from "react";

class Hello_class extends Component {
  render() {
    return <h1>class component Example</h1>;
  }
}
class sum extends Component {
  render() {
    return (
      <label>
        4+5=9
        <br></br>
        hello
      </label>
    );
  }
}
// export default Hello_class;
export default sum;
