// class component starts

import logo from "./logo.svg";
import "./App.css";

import Hello_func from "./component_folder/Hello_func";
import Hello_class from "./component_folder/Hello_class";
function App() {
  return (
    <div>
      <Hello_class />
    </div>
  );
}

export default App;

// class component ends

// functional Component starts

// import logo from "./logo.svg";
// import "./App.css";

// import Hello_func from "./component_folder/Hello_func";

// function App() {
//   return (
//     <div>
//       <Hello_func />
//       <Hello_func />
//     </div>
//   );
// }

// export default App;

// functional Component ends

// <div className="App">
//   <header className="App-header">
//     <h1>hello world</h1>
//     <p>hello world</p>
//   </header>
// </div>
