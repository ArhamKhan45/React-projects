import react, { Component } from "react";

class Tableof2 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      number2: 2,
    };
  }
  Table2handler() {
    this.setState({
      number2: this.state.number2 + 2,
    });
  }
  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <p>{this.state.number2}</p>
        <button onClick={this.Table2handler.bind(this)}>table of 2</button>
      </div>
    );
  }
}
export default Tableof2;
