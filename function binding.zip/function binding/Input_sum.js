import React, { Component } from "react";
let y = 98;
class Input_sum extends Component {
  constructor(props) {
    super(props);
    this.state = {
      a: 0,
      b: 0,
      c: "",
    };
  }
  changehandler1 = (x) => {
    this.setState({
      a: x.target.value,
    });
  };
  changehandler2 = (x) => {
    this.setState({
      b: x.target.value,
    });
  };
  sum = () => {
    let a = parseInt(this.state.a);
    let b = parseInt(this.state.b);
    y = a + b;
    this.setState({
      c: y,
    });
    console.log(y);
  };
  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <h1>{this.state.a}</h1>
        <h1>{this.state.b}</h1>
        <input type="number" onChange={this.changehandler1}></input>
        <br></br>
        <input type="number" onChange={this.changehandler2}></input>
        <br></br>
        <button onClick={this.sum}>click me to add</button>
        <input type="number" value={this.state.c}></input>
        <p>{this.state.c}</p>
      </div>
    );
  }
}

export default Input_sum;
