import react, { Component } from "react";
let i = 0;
class One_to_ten extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
    };
    this.count_handler = this.count_handler.bind(this);
  }
  count_handler() {
    if (this.state.count < 10 && i == 0) {
      this.setState({
        count: this.state.count + 1,
      });
    }
    if (this.state.count == 10 && i == 0) {
      i = 1;
      //   console.log(i);
    }
    if (this.state.count > 0 && i == 1) {
      this.setState({
        count: this.state.count - 1,
      });
      //   console.log("helolo");
    }
    if (this.state.count == 1 && i == 1) {
      i = 0;
      console.log(i);
    }
  }

  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <p>{this.state.count}</p>
        <button onClick={this.count_handler}>Click me count</button>
      </div>
    );
  }
}
export default One_to_ten;
