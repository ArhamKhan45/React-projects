import logo from "./logo.svg";
import "./App.css";
import Tableof2 from "./component_folder/Tableof2";
import One_to_ten from "./component_folder/One_to_ten";
import Timesalert from "./component_folder/Timesalert";
import Input_sum from "./component_folder/Input_sum";

function App() {
  return (
    <div>
      <p> 1st method binding</p>
      <Tableof2 />
      <br></br>
      <p> 2st method binding</p>
      <One_to_ten />
      <br></br>
      <p> 3st method binding</p>
      <Timesalert />
      <p> 4st method binding</p>
      <Input_sum />
    </div>
  );
}

export default App;
