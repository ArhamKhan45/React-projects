import React from "react";
function LaptopChild(props) {
  const showdata = props.datasender.map((item) => {
    return (
      <div className="border w-25  d-inline-block  mt-5 text-center  mx-auto ">
        <h3>{item.title}</h3>
        <p>{item.description}</p>
        <label>Rs: {item.price}</label>
        <img src={item.images[0]} alt="" srcset="" />
      </div>
    );
  });

  return <div>{showdata}</div>;
}
export default LaptopChild;
