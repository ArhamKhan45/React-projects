import React from "react";

function Displaydata(props) {
  const showdata = props.vatData.map((item) => {
    return (
      <div className="float-start">
        <details>
          <summary>
            {item.id}. {item.title}
          </summary>
          <img src={item.thumbnail} alt={item.title} srcset="" />
          <p>{item.description}</p>
        </details>
      </div>
    );
  });
  return <>{showdata}</>;
}
export default Displaydata;
