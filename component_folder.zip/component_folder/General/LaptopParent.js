import React, { Component } from "react";
import JSON from "./Laptop_db.json";
import LaptopChild from "./LaptopChild";

class LaptopParent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      FakeData: JSON,
    };
  }
  render() {
    return <LaptopChild datasender={this.state.FakeData} />;
  }
}
export default LaptopParent;
