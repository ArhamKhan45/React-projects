import React, { Component } from "react";
import Displaydata from "./DisplayData";
import JSON from "./Database.json";

class Datashow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fakedata: JSON,
    };
  }
  render() {
    return (
      <>
        <Displaydata vatData={this.state.fakedata} />
      </>
    );
  }
}
export default Datashow;
