import React from "react";
function DropDown_Alert() {
  const city = [
    "Mumbai",
    "Delhi",
    "Uttar Pradesh",
    "Kolkata",
    "Goa",
    "Haryana",
  ];
  // const Alerthandler = (value) => {
  //   alert(value.target.value);
  // };
  function Alerthandler(value) {
    alert(value.target.value);
  }
  return (
    <div style={{ textAlign: "center" }}>
      <select onChange={Alerthandler}>
        {city.map((statename) => (
          <option value={statename}>{statename}</option>
        ))}
      </select>
    </div>
  );
}
export default DropDown_Alert;
