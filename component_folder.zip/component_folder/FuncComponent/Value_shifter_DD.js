import { render } from "@testing-library/react";
import React from "react";
function Value_shifter_DD() {
  const city = [
    "Mumbai",
    "Delhi",
    "Uttar Pradesh",
    "Kolkata",
    "Goa",
    "Haryana",
  ];
  //   const Alerthandler = (value) => {
  //     alert(value.target.value);
  //   };
  function Alerthandler(value) {
    X = value.target.value;
 
  }
  let x;
  return (
    <div style={{ textAlign: "center" }}>
      <select onChange={(x = Alerthandler)}>
        {city.map((statename) => (
          <option value={statename}>{statename}</option>
        ))}
      </select>
      <input type="text" value={}></input>
    </div>
  );
}
export default Value_shifter_DD;
