import React from "react";

function CounterChild(props) {
  return (
    <>
      <input type="text" value={props.x}></input>
      <button onClick={props.counthandler}>Counter</button>
    </>
  );
}

export default CounterChild;
