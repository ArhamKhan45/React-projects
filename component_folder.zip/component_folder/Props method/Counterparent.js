import React, { Component } from "react";
import CounterChild from "./CounterChild";
class Counterparent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
    };
  }
  countcounter = () => {
    this.setState({
      counter: this.state.counter + 1,
    });
  };
  render() {
    return (
      <>
        <p>{this.state.counter}</p>
        <CounterChild counthandler={this.countcounter} x={this.state.counter} />
      </>
    );
  }
}
export default Counterparent;
