import React, { Component } from "react";
import Child from "./Child";
class Parent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      meraname: "Welcome Arham",
    };
  }
  nameprinter = () => {
    return alert(this.state.meraname);
  };
  render() {
    return (
      <>
        <Child handler={this.nameprinter} />
        <p>hi</p>
      </>
    );
  }
}

export default Parent;
