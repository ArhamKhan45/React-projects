import react, { Component } from "react";
class Counter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 1,
    };
  }
  CountChangeHandler = () => {
    // this.setState({
    //   count: this.state.count + 1,
    // });
    if (this.state.count < 10) {
      this.setState({
        count: this.state.count + 1,
      });
    }
  };

  render() {
    return (
      <div style={{ textAlign: "center", fontSize: 30 }}>
        <p> {this.state.count}</p>
        <button onClick={this.CountChangeHandler}> count changer</button>
      </div>
    );
  }
}
export default Counter;
