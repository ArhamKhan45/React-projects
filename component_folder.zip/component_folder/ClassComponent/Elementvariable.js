import React, { Component } from "react";

// Element variable rendering

class Elementvariable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: false,
    };
  }

  render() {
    let message;
    if (this.state.message) {
      message = (
        <div>
          <p> Morning</p>
        </div>
      );
    } else {
      message = (
        <div>
          <p> Nyt</p>
        </div>
      );
    }
    return message;
  }
}

export default Elementvariable;
