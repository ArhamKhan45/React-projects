import react from "react";

function helloworld() {
  return <h1>helloworld</h1>;
}
function sum() {
  return <p>My name is arham</p>;
}
export default sum;
