import React, { Component } from "react";

// Element variable rendering

class TernaryOperator extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: false,
    };
  }

  render() {
    return this.state.message ? (
      <div> welcome delhi</div>
    ) : (
      <div> Welcome Arham</div>
    );
  }
}

export default TernaryOperator;
