import React, { Component } from "react";

// if/else

class UserGreating extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: false,
    };
  }

  render() {
    if (this.state.message)
      return (
        <div>
          <p>Good Morning</p>
        </div>
      );
    else {
      return (
        <div>
          <p>Good Nyt</p>
        </div>
      );
    }
  }
}

export default UserGreating;
