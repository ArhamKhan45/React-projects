import React, { Component } from "react";
class ValueShifter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "Mumbai",
    };
  }
  valuechanger(e) {
    this.setState({
      message: e.target.value,
    });
    console.log(this.state.message);
  }
  render() {
    const city = [
      "Mumbai",
      "Delhi",
      "Uttar Pradesh",
      "Kolkata",
      "Goa",
      "Haryana",
    ];
    return (
      <div>
        <select onChange={this.valuechanger.bind(this)}>
          {city.map((statename) => (
            <option>{statename}</option>
          ))}
        </select>
        <input type="text" value={this.state.message}></input>
      </div>
    );
  }
}

export default ValueShifter;
