import React, { Component } from "react";
class Minus_input extends Component {
  constructor(props) {
    super(props);
    this.state = {
      x1: "",
      x2: "",
      min: "",
    };
  }
  x1_handler = (e) => {
    this.setState({
      x1: e.target.value,
    });
  };
  x2_handler = (h) => {
    this.setState({
      x2: h.target.value,
    });
  };
  minus = () => {
    let a, b;
    a = parseInt(this.state.x1);
    b = parseInt(this.state.x2);
    this.setState({
      min: a - b,
    });
    console.log("hi");
  };
  render() {
    return (
      <div>
        <input type="Number" onChange={this.x1_handler}></input>
        <input type="Number" onChange={this.x2_handler}></input>
        <p>{this.state.x1}</p>
        <p>{this.state.x2}</p>
        <p>{this.state.min}</p>

        <input type="Number" value={this.state.min}></input>
        <button onClick={this.minus}>Minus</button>
      </div>
    );
  }
}
export default Minus_input;
