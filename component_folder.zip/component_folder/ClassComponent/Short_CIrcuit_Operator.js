import React, { Component } from "react";

// Element variable rendering

class Short_Circuit_Operator extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: true,
    };
  }

  render() {
    return this.state.message && <div>hello India</div>;
  }
}

export default Short_Circuit_Operator;
