import React, { Component } from "react";

class Timesalert extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 1,
    };
  }

  clickme10() {
    if (this.state.count <= 10) {
      this.setState({
        count: this.state.count + 1,
      });
      if (this.state.count == 10) {
        alert("count value is " + this.state.count);
        this.setState({
          count: 1,
        });
      }
    }
    console.log(this.state.count);
  }
  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <p>{this.state.count}</p>
        <button onClick={() => this.clickme10()}>10 times click me</button>
      </div>
    );
  }
}
export default Timesalert;
