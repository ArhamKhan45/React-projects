import React, { Component } from "react";
class Text_field_20 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: "",
    };
  }
}
export default Text_field_20;
