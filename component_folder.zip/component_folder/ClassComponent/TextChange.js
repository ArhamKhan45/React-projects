import React, { Component } from "react";
class TextChange extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: "Arham Khan",
    };
  }
  textchanger = () => {
    this.setState({
      text: "HEllO WORLD",
    });
  };
  render() {
    return (
      <div>
        {this.state.text}
        <br></br>
        <button onClick={this.textchanger}>Text-change</button>
      </div>
    );
  }
}

// render() {
//   return (
//     <div>
//       <button onClick="">Text-change</button>
//     </div>
//   );
// }

export default TextChange;
