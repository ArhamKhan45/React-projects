import React, { Component } from "react";

class Color_background extends Component {
  constructor(props) {
    super(props);
    this.state = {
      color: "",
    };
  }
  color_applied() {
    return (document.body.style.background = this.state.color);
  }
  Changehandler = (x) => {
    this.setState({
      color: x.target.value,
    });
  };
  render() {
    return (
      <div style={{ textAlign: "center", marginTop: "30px" }}>
        <label>Enter Color Name:</label>
        <br></br> <br></br>
        <input type="text" onChange={this.Changehandler}></input>
        <br></br> <br></br>
        <button onClick={this.color_applied.bind(this)}>
          Apply_background_color
        </button>
      </div>
    );
  }
}
export default Color_background;
