// import "./App.css";
import ReactCarousel from "./Components/ReactCarousel";

import Routing from "./Components/Routing";

function App() {
  return (
    <div className="App">
      {/* <ReactCarousel /> */}
      <Routing />
    </div>
  );
}

export default App;
