import React from "react";

export default function Thanks() {
  return (
    <div>
      <h1>Thank You,Your form has been submitted</h1>
    </div>
  );
}
