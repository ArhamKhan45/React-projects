import React from "react";

const greatteam_data = [
  {
    id: 1,
    Name: "Nadeem",
    title: "FOUNDER",
    image: require("./images/team person.jpg"),
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates tempore perferendis nostrum magnam iure omnis at.",
    twitter: "",
    gmail: "",
  },
  {
    id: 2,
    Name: "Arham Khan",
    title: "DESIGNER",
    image: require("./images/team person.jpg"),
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates tempore perferendis nostrum magnam iure omnis at.",
    twitter: "",
    gmail: "",
  },
  {
    id: 3,
    Name: "Faiz Elahi",
    title: "DEVELOPER",
    image: require("./images/team person.jpg"),
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates tempore perferendis nostrum magnam iure omnis at.",
    twitter: "",
    gmail: "",
  },
  {
    id: 4,
    Name: "John Doe",
    title: "FOUNDER",
    image: require("./images/team person.jpg"),
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates tempore perferendis nostrum magnam iure omnis at.",
    twitter: "",
    gmail: "",
  },
];

export default greatteam_data;
