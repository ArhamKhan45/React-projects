const data = [
  {
    id: 1,
    image: require("./images/g1.jpg"),
    altimg: "yess",
  },
  {
    id: 2,
    image: require("./images/g2.jpg"),
  },
  {
    id: 3,
    image: require("./images/g3.jpg"),
  },
  {
    id: 4,
    image: require("./images/g4.jpg"),
  },
  {
    id: 5,
    image: require("./images/g5.jpg"),
  },
  {
    id: 6,
    image: require("./images/g7.jpg"),
  },
  {
    id: 7,
    image: require("./images/g8.jpg"),
  },
  {
    id: 8,
    image: require("./images/g9.jpg"),
  },
  {
    id: 9,
    image: require("./images/g10.jpg"),
  },
  {
    id: 10,
    image: require("./images/g11.jpg"),
  },
  {
    id: 1,
    image: require("./images/g1.jpg"),
    altimg: "yess",
  },
  {
    id: 2,
    image: require("./images/g2.jpg"),
  },
  {
    id: 3,
    image: require("./images/g3.jpg"),
  },
  {
    id: 4,
    image: require("./images/g4.jpg"),
  },
  {
    id: 5,
    image: require("./images/g5.jpg"),
  },
  {
    id: 6,
    image: require("./images/g7.jpg"),
  },
  {
    id: 7,
    image: require("./images/g8.jpg"),
  },
  {
    id: 8,
    image: require("./images/g9.jpg"),
  },
  {
    id: 9,
    image: require("./images/g10.jpg"),
  },
  {
    id: 10,
    image: require("./images/g11.jpg"),
  },
];

export default data;
