const data = [
  {
    id: 1,
    title: "CREATIVE AGENCY  FROM INDIA",
    titleCaption: "POWERED 94 CLIENTS  TILL TODAY",
    titleCaptioncolored: "94 CLIENTS TODAY",
    image: require("./images/vintage.png"),
    description:
      "WE ARE A FULL SERVICE DESIGN AGENCY FROM THE HEART OF LONDON.WE CREATE PERFECT BRANDS, VIBRANT IDENTITIES,OUTSTANDING WEBSITES AND CREATIVE CONCEPTS",
    imagebar: require("./images/vintagebar.jpg"),
  },
];
export default data;
