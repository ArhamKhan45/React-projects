const Servicedata = [
  {
    id: 1,
    class: "fa-solid fa-file",
    label: "Digital Experience",
    description:
      "We are a full service design agency from the heart of London. We create perfect brands, vibrant identities, outstanding websites and creative concepts",
  },
  {
    id: 2,
    class: "fa-solid fa-id-card",
    label: "Branding & Identity",
    description:
      "We are a full service design agency from the heart of London. We create perfect brands, vibrant identities, outstanding websites and creative concepts",
  },
  {
    id: 3,
    class: "fa-solid fa-tv",
    label: "Web Publication",
    description:
      "We are a full service design agency from the heart of London. We create perfect brands, vibrant identities, outstanding websites and creative concepts",
  },
  {
    id: 4,
    class: "fa-solid fa-envelope",
    label: "Motion Graphics",
    description:
      "We are a full service design agency from the heart of London. We create perfect brands, vibrant identities, outstanding websites and creative concepts",
  },
];
export default Servicedata;
