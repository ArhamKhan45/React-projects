import logo from "./logo.svg";
import "./App.css";
import Rs_to_dollar from "./component_folder/Rs_to_dollar";
import Data_transfer from "./component_folder/Data_transfer";
import Color_background from "./component_folder/Color_background";
function App() {
  return (
    <div>
      <Rs_to_dollar />
      <Data_transfer />
      <Color_background />
    </div>
  );
}

export default App;

// 2 boxes 1 data + enter  +1 button  +2 box-data
// input box  +color + button+ bacground green
// rs to dollar
