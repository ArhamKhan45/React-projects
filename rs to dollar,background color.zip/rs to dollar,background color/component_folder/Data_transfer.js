import react, { Component } from "react";

class Data_transfer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Currency: "",
      ChangedCurrency: "",
    };
  }
  textsender(e) {
    this.setState({
      Currency: e.target.value,
    });
  }
  CurrencyChange() {
    let x;
    x = parseInt(this.state.Currency);
    this.setState({
      ChangedCurrency: x,
      Currency: "",
    });
  }
  render() {
    return (
      <div style={{ textAlign: "center", marginTop: "30px" }}>
        <label>box 1</label>
        <input
          style={{ marginLeft: " 30px" }}
          type="number"
          value={this.state.Currency}
          onChange={this.textsender.bind(this)}
        ></input>
        <br></br> <br></br>
        <label>box 2</label>
        <input
          style={{ marginLeft: " 30px" }}
          type="number"
          value={this.state.ChangedCurrency}
        ></input>
        <br></br> <br></br>
        <button onClick={this.CurrencyChange.bind(this)}>Data transfer</button>
      </div>
    );
  }
}
export default Data_transfer;
