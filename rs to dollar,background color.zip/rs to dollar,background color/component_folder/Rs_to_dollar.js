import react, { Component } from "react";

class Rs_to_dollar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Currency: "",
      ChangedCurrency: "",
    };
  }
  textsender(e) {
    this.setState({
      Currency: e.target.value,
    });
  }
  CurrencyChange() {
    let x;
    x = parseInt(this.state.Currency);
    console.log(x);
    this.setState({
      ChangedCurrency: x * 0.012094,
      // Currency: "",
    });
  }
  render() {
    return (
      <div style={{ textAlign: "center", marginTop: "30px" }}>
        <label>Rs</label>
        <input
          style={{ marginLeft: " 55px" }}
          type="number"
          value={this.state.Currency}
          onChange={this.textsender.bind(this)}
        ></input>
        <br></br> <br></br>
        <label>Dollar</label>
        <input
          style={{ marginLeft: " 30px" }}
          type="number"
          value={this.state.ChangedCurrency}
        ></input>
        <br></br> <br></br>
        <button onClick={this.CurrencyChange.bind(this)}>
          converter Rs to Dollar
        </button>
        {/* <p>{this.state.Currency}</p>
        <p>{this.state.ChangedCurrency}</p> */}
      </div>
    );
  }
}
export default Rs_to_dollar;
