import React, { useState } from "react";

import "../Style/Index.css";
function Index() {
  const [title, settitle] = useState("Service Request #321654");
  const [reqDetailcount, setreqDetailcount] = useState(2);
  const [Attachmentcount, setAttachmentcount] = useState(3);
  const [notesCount, setnotesCount] = useState(4);
  const [LinkedReqCount, setLinkedReqCount] = useState(6);

  const infoIcon = (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      height="20"
      viewBox="0 96 960 960"
      width="20"
    >
      <path d="M453 776h60V536h-60v240Zm26.982-314q14.018 0 23.518-9.2T513 430q0-14.45-9.482-24.225-9.483-9.775-23.5-9.775-14.018 0-23.518 9.775T447 430q0 13.6 9.482 22.8 9.483 9.2 23.5 9.2Zm.284 514q-82.734 0-155.5-31.5t-127.266-86q-54.5-54.5-86-127.341Q80 658.319 80 575.5q0-82.819 31.5-155.659Q143 347 197.5 293t127.341-85.5Q397.681 176 480.5 176q82.819 0 155.659 31.5Q709 239 763 293t85.5 127Q880 493 880 575.734q0 82.734-31.5 155.5T763 858.316q-54 54.316-127 86Q563 976 480.266 976Zm.234-60Q622 916 721 816.5t99-241Q820 434 721.188 335 622.375 236 480 236q-141 0-240.5 98.812Q140 433.625 140 576q0 141 99.5 240.5t241 99.5Zm-.5-340Z" />
    </svg>
  );

  return (
    <div className="mainServiceBox">
      <h1 className="titlefix">{title}</h1>
      <div className="processbox">{infoIcon} In process </div>

      <div class="accordion accordion-flush" id="accordionFlushExample">
        <div class="accordion-item">
          <h2 class="accordion-header" id="flush-headingOne">
            <button
              class="accordion-button collapsed customtext"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#flush-collapseOne"
              aria-expanded="false"
              aria-controls="flush-collapseOne"
            >
              Service Request and Account Details
            </button>
          </h2>
          <div
            id="flush-collapseOne"
            class="accordion-collapse collapse"
            aria-labelledby="flush-headingOne"
            data-bs-parent="#accordionFlushExample"
          >
            <div class="custom-accordian-body ">
              <p className="miniheading">SR Details</p>
              <div className="row">
                <div className="col-6 col-lg-3 ">
                  <p>
                    <span className="fw-semibold">Service Request Type</span>
                    <br />
                    <span>Contact info Update</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold">Channels</span>
                    <br />
                    <span>WIPS</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 ms-auto">
                  <p>
                    <span className="fw-semibold">Target completions</span>
                    <br />
                    <span>9/1/2022 10:50:00 AM</span> <br />
                  </p>
                </div>

                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold">
                      Override Target Completion
                    </span>
                    <br />
                    <span>YES</span> <br />
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-6 col-lg-3 ">
                  <p>
                    <span className="fw-semibold">Group</span>
                    <br />
                    <span>Group 3</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold">Assign to</span>
                    <br />
                    <span>Carol Burton</span> <br />
                  </p>
                </div>

                <div className="col-6 col-lg-6 me-auto  ">
                  <p>
                    <span className="fw-semibold">New Completion Date</span>
                    <br />
                    <span>02/22/2023 10:50 AM</span> <br />
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-12">
                  <p>
                    <span className="fw-semibold">Bulk Requests</span>
                    <br />
                    <span>15</span> <br />
                  </p>
                </div>
                <div className="border-line"></div>
                <p className="miniheading">Account Details</p>
                <div className="row">
                  <div className="col-6 col-lg-3 ">
                    <p>
                      <span className="fw-semibold">System of Record</span>
                      <br />
                      <span>LIQ</span> <br />
                    </p>
                  </div>
                  <div className="col-6 col-lg-3 me-auto">
                    <p>
                      <span className="fw-semibold">Deal</span>
                      <br />
                      <span>321654</span> <br />
                    </p>
                  </div>
                  <div className="col-6 col-lg-3 ms-auto">
                    <p>
                      <span className="fw-semibold">Facility</span>
                      <br />
                      <span>3829992</span> <br />
                    </p>
                  </div>

                  <div className="col-6 col-lg-3 me-auto">
                    <p>
                      <span className="fw-semibold">Loan</span>
                      <br />
                      <span>533564</span> <br />
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="accordion-item container-fluid">
          <div className="row px-0 ">
            <div
              class="accordion-header col-3  col-xl-2 px-0"
              id="flush-headingTwo"
            >
              <button
                class="accordion-button collapsed customtext "
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseTwo"
                aria-expanded="false"
                aria-controls="flush-collapseTwo"
              >
                Request Details{" "}
                <span className=" counterbox">{reqDetailcount}</span>
              </button>
            </div>
            <div
              class="accordion-header col-3  col-xl-2 px-0"
              id="flush-headingThree"
            >
              <button
                class="accordion-button collapsed customtext"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseThree"
                aria-expanded="false"
                aria-controls="flush-collapseThree"
              >
                Attachments{" "}
                <span className=" counterbox">{Attachmentcount}</span>
              </button>
            </div>
            <div
              class="accordion-header col-3 col-xl-2 px-0"
              id="flush-headingFour"
            >
              <button
                class="accordion-button collapsed customtext"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseFour"
                aria-expanded="false"
                aria-controls="flush-collapseFour"
              >
                Notes
                <span className=" counterbox">{notesCount}</span>
              </button>
            </div>
            <div
              class="accordion-header col-3 col-xl-2 px-0"
              id="flush-headingFive"
            >
              <button
                class="accordion-button collapsed customtext"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseFive"
                aria-expanded="false"
                aria-controls="flush-collapseFive"
              >
                Linked Request
                <span className=" counterbox">{LinkedReqCount}</span>
              </button>
            </div>
          </div>
          <div
            id="flush-collapseTwo"
            class="accordion-collapse collapse"
            aria-labelledby="flush-headingTwo"
            data-bs-parent="#accordionFlushExample"
          >
            <div class="custom-accordian-body mx-lg-5">
              <p className="miniheading">Request Details</p>
              <div className="row">
                <div className="col-6 col-lg-3 ">
                  <p>
                    <span className="fw-semibold">Distribution Method</span>
                    <br />
                    <span>Wire</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold"> Amount (USD)</span>
                    <br />
                    <span>120,000.00</span> <br />
                  </p>
                </div>
              </div>
              <div>
                <p>
                  <span className="fw-semibold"> Comment</span>
                  <br />
                  <span>
                    Sed maximus aliquam volutpat. In in nisl at metus laoreet
                    dictum. Donec sodales sapien arcu, non tincidunt tortor
                    egestas in. Fusce
                  </span>
                  <br />
                </p>
              </div>
            </div>
          </div>
          <div
            id="flush-collapseThree"
            class="accordion-collapse collapse"
            aria-labelledby="flush-headingThree"
            data-bs-parent="#accordionFlushExample"
          >
            <div class="custom-accordian-body  mx-lg-5">
              <p className="miniheading">Details</p>
              <div className="row">
                <div className="col-6 col-lg-3 ">
                  <p>
                    <span className="fw-semibold">Request Type</span>
                    <br />
                    <span>Contact info Update</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold">Channels</span>
                    <br />
                    <span>WIPS</span> <br />
                  </p>
                </div>
              </div>
              <div>
                <p>
                  <span className="fw-semibold"> Comment</span>
                  <br />
                  <span>
                    Sed maximus aliquam volutpat. In in nisl at metus laoreet
                    dictum. Donec sodales sapien arcu, non tincidunt tortor
                    egestas in. Fusce
                  </span>
                  <br />
                </p>
              </div>
            </div>
          </div>
          <div
            id="flush-collapseFour"
            class="accordion-collapse collapse"
            aria-labelledby="flush-headingFour"
            data-bs-parent="#accordionFlushExample"
          >
            <div class="custom-accordian-body mx-lg-5">
              <p className="miniheading">Notes Details</p>
              <div className="row">
                <div className="col-6 col-lg-3 ">
                  <p>
                    <span className="fw-semibold">Request Type</span>
                    <br />
                    <span>Contact info Update</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold">Channels</span>
                    <br />
                    <span>WIPS</span> <br />
                  </p>
                </div>
              </div>
              <div>
                <p>
                  <span className="fw-semibold"> Comment</span>
                  <br />
                  <span>
                    Sed maximus aliquam volutpat. In in nisl at metus laoreet
                    dictum. Donec sodales sapien arcu, non tincidunt tortor
                    egestas in. Fusce
                  </span>
                  <br />
                </p>
              </div>
            </div>
          </div>
          <div
            id="flush-collapseFive"
            class="accordion-collapse collapse"
            aria-labelledby="flush-headingFive"
            data-bs-parent="#accordionFlushExample"
          >
            <div class="custom-accordian-body mx-lg-5">
              <p className="miniheading"> Det</p>
              <div className="row">
                <div className="col-6 col-lg-3 ">
                  <p>
                    <span className="fw-semibold">Request Type</span>
                    <br />
                    <span>Contact info Update</span> <br />
                  </p>
                </div>
                <div className="col-6 col-lg-3 me-auto">
                  <p>
                    <span className="fw-semibold">Channels</span>
                    <br />
                    <span>WIPS</span> <br />
                  </p>
                </div>
              </div>
              <div>
                <p>
                  <span className="fw-semibold"> Comment</span>
                  <br />
                  <span>
                    Sed maximus aliquam volutpat. In in nisl at metus laoreet
                    dictum. Donec sodales sapien arcu, non tincidunt tortor
                    egestas in. Fusce
                  </span>
                  <br />
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Index;
