// import "./App.css";

import Index from "./Components/Index.jsx";

function App() {
  return (
    <div className="App">
      <Index />
    </div>
  );
}

export default App;
